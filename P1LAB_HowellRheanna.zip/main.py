userNum = int(input())
userNumSquared = userNum * userNum   # Bug here; fix it when instructed
   
print(userNumSquared) 
# Output formatting issue here; fix it when instructed